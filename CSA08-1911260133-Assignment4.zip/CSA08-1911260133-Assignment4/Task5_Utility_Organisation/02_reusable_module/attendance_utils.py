import csv

def read_attendance(path):
    records = []
    with open(path, newline="", encoding="utf-8") as file:
        for row in csv.reader(file):
            if len(row) != 3:
                continue
            reg, date, status = (value.strip() for value in row)
            if reg and date and status in {"P", "A"}:
                records.append((reg, date, status))
    return records

def percentage(present, total):
    return (present / total * 100) if total else 0.0

def below_threshold(records, limit=75):
    return [row for row in records if row["percentage"] < limit]

import csv

def write_summary(records, path):
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["register_number", "present", "total", "percentage"])
        writer.writeheader(); writer.writerows(records)

def write_below_75(records, path):
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["register_number", "percentage"])
        writer.writeheader()
        for row in records:
            if row["percentage"] < 75:
                writer.writerow({"register_number": row["register_number"], "percentage": row["percentage"]})
