from pathlib import Path
from reader import read_attendance
from stats import percentage
from report import write_summary, write_below_75
def main():
 p=Path("day.csv")
 if not p.exists(): p.write_text("191,2026-10-01,P\n192,2026-10-01,A\n",encoding="utf-8")
 grouped={}
 for reg,date,status in read_attendance(p):
  grouped.setdefault(reg,[0,0]); grouped[reg][1]+=1
  if status=="P": grouped[reg][0]+=1
 rows=[{"register_number":r,"present":v[0],"total":v[1],"percentage":round(percentage(*v),2)} for r,v in sorted(grouped.items())]
 write_summary(rows,"attendance_summary.csv"); write_below_75(rows,"below_75.csv"); print(rows)
if __name__=="__main__": main()
