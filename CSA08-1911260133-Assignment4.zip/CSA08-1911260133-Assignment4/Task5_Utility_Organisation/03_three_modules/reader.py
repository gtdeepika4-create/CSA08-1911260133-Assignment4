import csv

def read_attendance(path):
    records = []
    with open(path, newline="", encoding="utf-8") as file:
        for row in csv.reader(file):
            if len(row) != 3:
                continue
            reg, date, status = (value.strip() for value in row)
            if reg and date and status in {"P", "A"}:
                records.append((reg, date, status))
    return records
