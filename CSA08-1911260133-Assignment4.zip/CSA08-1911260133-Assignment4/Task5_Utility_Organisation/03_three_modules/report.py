import csv

def write_summary(records, path):
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["register_number", "present", "total", "percentage"])
        writer.writeheader(); writer.writerows(records)

def write_below_75(records, path):
    with open(path, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["register_number", "percentage"])
        writer.writeheader()
        for row in records:
            if row["percentage"] < 75:
                writer.writerow({"register_number": row["register_number"], "percentage": row["percentage"]})
