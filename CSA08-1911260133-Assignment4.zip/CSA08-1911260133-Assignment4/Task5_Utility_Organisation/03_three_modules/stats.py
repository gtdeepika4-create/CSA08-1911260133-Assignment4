def percentage(present, total):
    return (present / total * 100) if total else 0.0

def below_threshold(records, limit=75):
    return [row for row in records if row["percentage"] < limit]
