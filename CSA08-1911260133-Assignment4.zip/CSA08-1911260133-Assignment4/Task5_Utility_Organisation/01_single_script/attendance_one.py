import csv

def read_attendance(path):
    with open(path, newline="", encoding="utf-8") as f:
        return [(r[0].strip(), r[1].strip(), r[2].strip()) for r in csv.reader(f) if len(r)==3 and r[0].strip() and r[1].strip() and r[2].strip() in {"P","A"}]
def percentage(present, total): return present / total * 100 if total else 0.0
def write_reports(records):
    with open("attendance_summary.csv", "w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["register_number","present","total","percentage"]); w.writerows(records)
    with open("below_75.csv", "w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["register_number","percentage"]); w.writerows([r[0],r[3]] for r in records if r[3] < 75)
def main():
    from pathlib import Path
    p=Path("day.csv")
    if not p.exists(): p.write_text("191,2026-10-01,P\n192,2026-10-01,A\n", encoding="utf-8")
    counts={}
    for reg,date,status in read_attendance(p):
        counts.setdefault(reg,[0,0]); counts[reg][1]+=1
        if status=="P": counts[reg][0]+=1
    records=[[reg,v[0],v[1],round(percentage(*v),2)] for reg,v in sorted(counts.items())]
    write_reports(records); print(records)
if __name__ == "__main__": main()
