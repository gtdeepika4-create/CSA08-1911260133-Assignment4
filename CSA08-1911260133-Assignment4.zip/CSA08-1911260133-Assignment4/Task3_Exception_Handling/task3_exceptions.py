import os
import tempfile
class InvalidRecord(Exception):
    """Raised when an attendance row is not in the required format."""
def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(
            f"expected 3 fields, found {len(parts)}"
        )
    register_number, date, status = [part.strip() for part in parts]
    if not register_number or not date:
        raise InvalidRecord("register number and date must not be empty")
    if status not in {"P", "A"}:
        raise InvalidRecord(f"invalid status '{status}'")
    return register_number, date, status
def summarise(path):
    present = 0
    absent = 0
    errors = []
    try:
        with open(path, "r", encoding="utf-8") as file:
            for number, line in enumerate(file, start=1):
                try:
                    _, _, status = parse_line(line)
                    if status == "P":
                        present += 1
                    else:
                        absent += 1
                except InvalidRecord as error:
                    errors.append((number, str(error)))
        # This else belongs to the outer try.
    except FileNotFoundError as error:
        raise FileNotFoundError(
            f"attendance file not found: {path}"
        ) from error
    except PermissionError as error:
        raise PermissionError(
            f"permission denied while reading: {path}"
        ) from error
    except UnicodeDecodeError as error:
        raise UnicodeError(
            f"invalid text encoding in: {path}"
        ) from error
    else:
        print("File processing completed.")
    finally:
        print("File processing attempt finished.")
    return present, absent, errors
if __name__ == "__main__":
    data = (
        "192311001,2026-10-08,P\n"
        "192311002,2026-10-08,A\n"
        "192311003,2026-10-08\n"
        "192311004,2026-10-08,L\n"
    )
    with tempfile.NamedTemporaryFile(
        "w", suffix=".csv", delete=False, encoding="utf-8"
    ) as temporary:
        temporary.write(data)
        filename = temporary.name
    try:
        print(summarise(filename))
    finally:
        os.remove(filename)
