from pathlib import Path
import csv
DEPARTMENTS = ("arts", "science", "commerce", "engineering", "management")
def valid_email(email):
    if email.count("@") != 1:
        return False
    local, domain = email.split("@")
    return bool(local and domain and "." in domain
                and not domain.startswith(".")
                and not domain.endswith("."))
def process(folder):
    folder = Path(folder)
    output = folder / "output"
    output.mkdir(parents=True, exist_ok=True)
    master = {}
    seen = set()
    errors = []
    for department in DEPARTMENTS:
        path = folder / f"{department}.csv"
        try:
            with path.open("r", newline="", encoding="utf-8") as file:
                for line_no, row in enumerate(csv.reader(file), start=1):
                    if len(row) != 5:
                        errors.append((str(path), line_no, "expected 5 fields"))
                        continue
                    reg, name, dept, email, event_text = [
                        value.strip() for value in row
                    ]
                    reg = reg.upper()  # normalise before duplicate checks
                    if not reg or not name or not valid_email(email):
                        errors.append((str(path), line_no,
                                       "invalid register number, name or email"))
                        continue
                    events = {e.strip() for e in event_text.split(";") if e.strip()}
                    if not events:
                        errors.append((str(path), line_no, "no valid events"))
                        continue
                    if reg in seen:
                        record = master[reg]
                        if record["name"] != name:
                            errors.append((str(path), line_no,
                                           "duplicate register number with name conflict"))
                        record["events"].update(events)
                        record["emails"].add(email.lower())
                    else:
                        seen.add(reg)
                        master[reg] = {
                            "name": name,
                            "department": dept,
                            "emails": {email.lower()},
                            "events": events
                        }
        except (FileNotFoundError, PermissionError, UnicodeDecodeError) as error:
            errors.append((str(path), 0,
                           type(error).__name__ + ": " + str(error)))
    event_map = {}
    for reg, record in master.items():
        for event in record["events"]:
            event_map.setdefault(event, []).append(reg)
    with (output / "master.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.writer(file)
        writer.writerow(["register_number", "name", "department", "emails", "events"])
        for reg, record in sorted(master.items()):
            writer.writerow([
                reg, record["name"], record["department"],
                ";".join(sorted(record["emails"])),
                ";".join(sorted(record["events"]))
            ])
    for event, registers in sorted(event_map.items()):
        safe_name = "".join(ch for ch in event if ch.isalnum() or ch in "_-")
        (output / f"{safe_name}.txt").write_text(
            "\n".join(sorted(registers)) + "\n", encoding="utf-8"
        )
    with (output / "errors.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.writer(file)
        writer.writerow(["filename", "line_number", "reason"])
        writer.writerows(errors)
    with (output / "summary.txt").open("w", encoding="utf-8") as file:
        file.write(f"Unique registrations: {len(master)}\n")
        file.write(f"Events: {len(event_map)}\n")
        file.write(f"Logged errors: {len(errors)}\n")
    return master, errors, event_map
if __name__ == "__main__":
    folder = Path("fest_data")
    folder.mkdir(exist_ok=True)
    (folder / "arts.csv").write_text(
        "191,Asha,Arts,asha@example.com,Dance;Music\n"
        "191,Asha,Arts,asha@example.com,Drama\n"
        "192,Bala,Arts,bad-email,Dance\n"
        "193,Chitra,Arts,chitra@example.com,Music\n"
        "BAD\n", encoding="utf-8"
    )
    (folder / "science.csv").write_text(
        "194,Dev,Science,dev@example.com,Quiz;Music\n",
        encoding="utf-8"
    )
    result = process(folder)
    print("accepted unique registrations:", len(result[0]))
    print("events:", {key: len(value) for key, value in sorted(result[2].items())})
    print("logged errors:", len(result[1]))
