from pathlib import Path
def save_returns(books, log_path="returns.log"):
    with open(log_path, "a", encoding="utf-8") as log:
        for book in books:
            clean = book.rstrip("\r\n")
            if clean:
                log.write(clean + "\n")
def process(day_file, log_path="returns.log", error_path="errors.log"):
    try:
        with open(day_file, "r", encoding="utf-8") as source:
            books = source.readlines()
        save_returns(books, log_path)
    except (FileNotFoundError, PermissionError, UnicodeDecodeError) as error:
        with open(error_path, "a", encoding="utf-8") as error_file:
            error_file.write(
                f"{day_file}: {type(error).__name__}: {error}\n"
            )
if __name__ == "__main__":
    Path("day1.txt").write_text("Book A\nBook B\n", encoding="utf-8")
    Path("day2.txt").write_text("Book C\n", encoding="utf-8")
    Path("day3.txt").write_text("Book D\n", encoding="utf-8")
    Path("returns.log").write_text("", encoding="utf-8")
    for day in ("day1.txt", "day2.txt", "day3.txt"):
        process(day)
    print("Contents of returns.log:")
    print(Path("returns.log").read_text(encoding="utf-8"), end="")
