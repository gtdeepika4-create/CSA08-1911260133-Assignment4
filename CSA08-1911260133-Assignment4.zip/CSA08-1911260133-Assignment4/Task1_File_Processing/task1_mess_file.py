from decimal import Decimal, InvalidOperation
from pathlib import Path
def process_mess_file(filename):
    total = Decimal("0.00")
    report = []
    rejected = []
    with open(filename, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if not line.strip():
                continue
            parts = [item.strip() for item in line.rstrip("\n").split(",")]
            try:
                if len(parts) != 3:
                    raise ValueError("expected 3 fields")
                register_number, name, amount_text = parts
                amount = Decimal(amount_text)
                if not amount.is_finite():
                    raise ValueError("amount must be finite")
                total += amount
                report.append(f"{register_number} {name} {amount:.2f}")
            except (ValueError, InvalidOperation) as error:
                rejected.append((line_number, line.rstrip("\n"), str(error)))
    return report, total, rejected
if __name__ == "__main__":
    sample = Path("mess_sample.txt")
    sample.write_text(
        "191,Asha,1250.50\n192,Bala,900\nBAD\n193,Chitra,abc\n",
        encoding="utf-8"
    )
    report, total, rejected = process_mess_file(sample)
    print("\n".join(report))
    print("Total", total)
    print("Rejected", rejected)
