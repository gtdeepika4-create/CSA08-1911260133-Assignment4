from pathlib import Path
import csv
def monthly_attendance(files, expected_days, output_folder="."):
    if expected_days <= 0:
        raise ValueError("expected_days must be greater than zero")
    counts = {}
    errors = []
    seen_records = set()
    output = Path(output_folder)
    output.mkdir(parents=True, exist_ok=True)
    for filename in files:
        try:
            with open(filename, "r", newline="", encoding="utf-8") as file:
                for line_no, row in enumerate(csv.reader(file), start=1):
                    if len(row) != 3:
                        errors.append((str(filename), line_no, "expected 3 fields"))
                        continue
                    reg, date, status = [value.strip() for value in row]
                    if not reg or not date or status not in {"P", "A"}:
                        errors.append((str(filename), line_no, "invalid record"))
                        continue
                    record_key = (reg, date)
                    if record_key in seen_records:
                        errors.append((str(filename), line_no,
                                       "duplicate student/date record"))
                        continue
                    seen_records.add(record_key)
                    item = counts.setdefault(reg, {"P": 0, "A": 0})
                    item[status] += 1
        except (FileNotFoundError, PermissionError, UnicodeDecodeError) as error:
            errors.append((str(filename), 0, type(error).__name__ + ": " + str(error)))
    with (output / "attendance_summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.writer(file)
        writer.writerow(["register_number", "present", "absent",
                         "recorded_days", "percentage"])
        for reg, item in sorted(counts.items()):
            recorded = item["P"] + item["A"]
            percentage = item["P"] / expected_days * 100
            writer.writerow([reg, item["P"], item["A"],
                             recorded, round(percentage, 2)])
    with (output / "below_75.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.writer(file)
        writer.writerow(["register_number", "percentage"])
        for reg, item in sorted(counts.items()):
            percentage = item["P"] / expected_days * 100
            if percentage < 75:
                writer.writerow([reg, round(percentage, 2)])
    with (output / "errors.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.writer(file)
        writer.writerow(["filename", "line_number", "reason"])
        writer.writerows(errors)
    return counts, errors
def monthly_attendance_from_folder(input_folder, expected_days, output_folder="attendance_reports"):
    folder = Path(input_folder)
    daily_files = sorted(folder.glob("*.csv"))
    return monthly_attendance(daily_files, expected_days, output_folder)
if __name__ == "__main__":
    sample = Path("attendance_day.csv")
    sample.write_text(
        "191,2026-10-01,P\n192,2026-10-01,A\n193,2026-10-01,L\n",
        encoding="utf-8"
    )
    counts, errors = monthly_attendance_from_folder(".", 1, "attendance_reports")
    percentages = {
        reg: round(item["P"] / 1 * 100, 2)
        for reg, item in sorted(counts.items())
    }
    print(percentages, errors)
    print("Generated: attendance_summary.csv, below_75.csv, errors.csv")
